/** @type {import('post-load-config').config}  */

const config = {
  plugins: {
    tailwindcss: {}
  },
};

export default config;
